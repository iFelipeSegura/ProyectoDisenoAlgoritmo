# JOSEO Modularizado

## Ejecutar proyecto

```bash
pip install -r requirements.txt
streamlit run joseo/app.py
```

## Estructura

- `services/` → lógica de rutas y algoritmo A*
- `ui/` → estilos, componentes y mapa
- `data/` → datos de cuarteles
- `config.py` → configuración general y API KEY
