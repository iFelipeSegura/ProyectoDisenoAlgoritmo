import folium


def crear_mapa(rutas, cuarteles, destino, origen):
    m = folium.Map(
        location=[destino.latitude, destino.longitude],
        zoom_start=14,
        tiles="CartoDB dark_matter"
    )

    colores = ["red", "blue", "green"]

    for i, r in enumerate(rutas):
        puntos = [(lat, lon) for lon, lat in r["ruta"]]

        folium.PolyLine(
            puntos,
            color=colores[i],
            weight=7 if i == 0 else 4,
            opacity=0.85,
            tooltip=f"Ruta {i + 1}"
        ).add_to(m)

    for c in cuarteles:
        color = "green" if c["nombre"] == origen["nombre"] else "blue"

        folium.Marker(
            [c["lat"], c["lon"]],
            tooltip=c["nombre"],
            icon=folium.Icon(color=color, icon="fire")
        ).add_to(m)

    folium.Marker(
        [destino.latitude, destino.longitude],
        tooltip="Emergencia",
        icon=folium.Icon(color="red", icon="info-sign")
    ).add_to(m)

    return m
