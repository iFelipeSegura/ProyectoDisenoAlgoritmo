import streamlit as st


def render_header():
    st.markdown("""
    <div class="joseo-header">
        <div>
            <p class="joseo-title">🚒 J.O.S.E-O</p>
            <p class="joseo-subtitle">
                Jerarquía Optimizada de Salidas en Emergencias
            </p>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_cuarteles(cuarteles):
    st.markdown(
        '<p class="section-label">Cuarteles activos</p>',
        unsafe_allow_html=True
    )

    chips_html = '<div class="cuarteles-grid">'

    for c in cuarteles:
        chips_html += f'<span class="cuartel-chip">{c["nombre"]}</span>'

    chips_html += '</div>'

    st.markdown(chips_html, unsafe_allow_html=True)


def render_resultado(resultado):
    st.markdown(f"""
    <div class="resultado-banner">
        <div>
            <div style="font-size:0.7rem;color:#64748b;">
                Unidad despachada
            </div>

            <div style="font-size:1rem;font-weight:600;color:#22c55e;">
                🚒 {resultado['cuartel']['nombre']}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="resultado-banner">
        <div>
            <div style="font-size:0.7rem;color:#64748b;">
                Costo A*
            </div>

            <div style="font-size:1rem;font-weight:600;color:#60a5fa;">
                {int(resultado['costo_astar'] // 60)}m
                {int(resultado['costo_astar'] % 60)}s
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
