import streamlit as st

def cargar_estilos():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');

    html, body, [class*="css"] { font-family: 'IBM Plex Sans', sans-serif; }
    .stApp { background-color: #0d0f14; color: #e2e8f0; }

    .joseo-header {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 18px 0 8px 0;
        border-bottom: 2px solid #ff3b30;
        margin-bottom: 20px;
    }

    .joseo-title {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 1.6rem;
        font-weight: 600;
        color: #ffffff;
        letter-spacing: 0.02em;
        margin: 0;
    }

    .joseo-subtitle {
        font-size: 0.75rem;
        color: #64748b;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin: 2px 0 0 0;
    }

    .cuarteles-grid {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 18px;
    }

    .cuartel-chip {
        background: #1a1f2e;
        border: 1px solid #2d3748;
        color: #94a3b8;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-family: 'IBM Plex Mono', monospace;
    }

    .resultado-banner {
        background: linear-gradient(90deg, #0f2010 0%, #1a1f2e 100%);
        border-left: 3px solid #22c55e;
        padding: 10px 14px;
        border-radius: 0 6px 6px 0;
        margin-bottom: 12px;
    }

    #MainMenu, footer, header {
        visibility: hidden;
    }
    </style>
    """, unsafe_allow_html=True)
