import streamlit as st

from geopy.geocoders import Nominatim
from streamlit_folium import st_folium

from joseo.data.cuarteles import obtener_cuarteles
from joseo.services.routing import mejor_cuartel_hibrido
from joseo.ui.components import (
    render_cuarteles,
    render_header,
    render_resultado
)
from joseo.ui.map import crear_mapa
from joseo.ui.styles import cargar_estilos


st.set_page_config(
    layout="wide",
    page_title="J.O.S.E-O",
    page_icon="🚒"
)

cargar_estilos()

cuarteles = obtener_cuarteles()

render_header()

col_left, col_right = st.columns([1, 2.2], gap="large")

with col_left:
    render_cuarteles(cuarteles)

    direccion = st.text_input(
        "Dirección",
        placeholder="Ej: Av. Francisco de Aguirre 100"
    )

    calcular = st.button("CALCULAR RUTA")

    if calcular and direccion:
        try:
            geo = Nominatim(user_agent="joseo_app")

            destino = geo.geocode(
                direccion + ", La Serena, Chile"
            )

            resultado = mejor_cuartel_hibrido(
                cuarteles,
                destino
            )

            st.session_state["resultado"] = resultado
            st.session_state["destino"] = destino

        except Exception as e:
            st.error(f"Error: {e}")

    if "resultado" in st.session_state:
        render_resultado(
            st.session_state["resultado"]
        )

with col_right:
    if "resultado" in st.session_state:
        resultado = st.session_state["resultado"]
        destino = st.session_state["destino"]

        mapa = crear_mapa(
            resultado["rutas"],
            cuarteles,
            destino,
            resultado["cuartel"]
        )

        st_folium(
            mapa,
            width=None,
            height=580,
            use_container_width=True
        )
