# ui/components.py
# Capa de Interfaz (UI): Componentes y renderizado de la interfaz Streamlit

import streamlit as st
from streamlit_folium import st_folium

from ui.map import crear_mapa


def render_header():
    """Renderiza el encabezado principal de la aplicación."""
    st.markdown(
        """
        <div class="joseo-header">
            <div>
                <p class="joseo-title">🚒 J.O.S.E-O</p>
                <p class="joseo-subtitle">Jerarquía Optimizada de Salidas en Emergencias · La Serena, Chile</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_cuarteles_chips(cuarteles):
    """Renderiza los chips de cuarteles activos."""
    st.markdown('<p class="section-label">Cuarteles activos</p>', unsafe_allow_html=True)
    chips_html = '<div class="cuarteles-grid">'
    for c in cuarteles:
        chips_html += f'<span class="cuartel-chip">{c["nombre"]}</span>'
    chips_html += "</div>"
    st.markdown(chips_html, unsafe_allow_html=True)


def render_resultado(r):
    """Renderiza los banners con el resultado del cálculo A*."""
    st.markdown("<br>", unsafe_allow_html=True)

    st.markdown(
        f"""
        <div class="resultado-banner">
            <div>
                <div class="resultado-banner-label">Unidad despachada</div>
                <div class="resultado-banner-value">🚒 {r['cuartel']['nombre']}</div>
            </div>
        </div>
        <div class="resultado-banner" style="border-color:#3b82f6;background:linear-gradient(90deg,#0a1020 0%,#1a1f2e 100%);margin-top:-4px;">
            <div>
                <div class="resultado-banner-label">Algoritmo</div>
                <div class="resultado-banner-value" style="color:#60a5fa;font-size:0.82rem;">ORS + A* (heurística euclidiana)</div>
            </div>
        </div>
        <div class="resultado-banner" style="border-color:#a855f7;background:linear-gradient(90deg,#130a20 0%,#1a1f2e 100%);margin-top:-4px;">
            <div>
                <div class="resultado-banner-label">Costo A* óptimo</div>
                <div class="resultado-banner-value" style="color:#a855f7;font-size:0.82rem;">
                    {int(r['costo_astar'] // 60)}m {int(r['costo_astar'] % 60)}s
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_rutas(rutas):
    """Renderiza las tarjetas de rutas calculadas."""
    st.markdown(
        '<p style="font-size:0.65rem;color:#475569;text-transform:uppercase;letter-spacing:0.12em;'
        'font-family:IBM Plex Mono,monospace;margin:14px 0 8px 0;">Rutas calculadas</p>',
        unsafe_allow_html=True,
    )

    for i, ruta in enumerate(rutas):
        minutos = int(ruta["tiempo"] // 60)
        segundos = int(ruta["tiempo"] % 60)
        km = ruta["dist"] / 1000
        es_mejor = i == 0

        if es_mejor:
            border_color = "#ff3b30"
            bg_color = "#1f1214"
            badge_bg = "#ff3b3022"
            badge_color = "#ff3b30"
            tiempo_color = "#ff3b30"
            badge_texto = "A* ÓPTIMA"
        else:
            border_color = "#2d3748"
            bg_color = "#1a1f2e"
            badge_bg = "#3b82f622"
            badge_color = "#60a5fa"
            tiempo_color = "#f1f5f9"
            badge_texto = f"ALT {i}"

        st.markdown(
            f"""
            <div style="background:{bg_color};border:1px solid {border_color};border-radius:6px;
                padding:10px 14px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;">
                <div>
                    <span style="display:inline-block;padding:1px 7px;border-radius:3px;font-size:0.65rem;
                        font-family:'IBM Plex Mono',monospace;background:{badge_bg};color:{badge_color};
                        margin-bottom:4px;">{badge_texto}</span>
                    <div style="font-size:1.2rem;font-weight:600;font-family:'IBM Plex Mono',monospace;
                        color:{tiempo_color};line-height:1.2;">
                        {minutos}:{segundos:02d} <span style="font-size:0.7rem;color:#64748b;">min</span>
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:0.85rem;color:#94a3b8;font-family:'IBM Plex Mono',monospace;">{km:.2f} km</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_mapa(r, destino, cuarteles):
    """Renderiza el mapa Folium con rutas y marcadores."""
    st.markdown(
        """
        <div style="display:flex;gap:14px;align-items:center;margin-bottom:8px;padding:6px 10px;
                    background:#1a1f2e;border-radius:4px;width:fit-content;">
            <span style="display:flex;align-items:center;gap:5px;font-size:0.72rem;color:#94a3b8;font-family:'IBM Plex Mono',monospace;">
                <span style="width:10px;height:10px;border-radius:50%;background:#ef4444;display:inline-block;"></span> Ruta A* óptima
            </span>
            <span style="display:flex;align-items:center;gap:5px;font-size:0.72rem;color:#94a3b8;font-family:'IBM Plex Mono',monospace;">
                <span style="width:10px;height:10px;border-radius:50%;background:#3b82f6;display:inline-block;"></span> Alternativa 1
            </span>
            <span style="display:flex;align-items:center;gap:5px;font-size:0.72rem;color:#94a3b8;font-family:'IBM Plex Mono',monospace;">
                <span style="width:10px;height:10px;border-radius:50%;background:#22c55e;display:inline-block;"></span> Alternativa 2
            </span>
        </div>
        """,
        unsafe_allow_html=True,
    )
    mapa = crear_mapa(r["rutas"], cuarteles, destino, r["cuartel"])
    st_folium(mapa, width=None, height=580, use_container_width=True)


def render_mapa_vacio():
    """Renderiza el placeholder del mapa cuando no hay resultados."""
    st.markdown(
        """
        <div style="height:580px;background:#1a1f2e;border-radius:6px;border:1px solid #2d3748;
                    display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;">
            <div style="font-size:2.5rem;opacity:0.3;">🗺️</div>
            <div style="color:#475569;font-family:'IBM Plex Mono',monospace;font-size:0.78rem;letter-spacing:0.1em;">
                INGRESE UNA DIRECCIÓN PARA VISUALIZAR
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
