# ui/map.py
# Capa de Interfaz (UI): Generación del mapa Folium

import folium


def crear_mapa(rutas, cuarteles, destino, origen):
    """
    Construye el mapa Folium con las rutas y marcadores de cuarteles y emergencia.

    Args:
        rutas:     Lista de rutas con geometría, distancia y tiempo.
        cuarteles: Lista de todos los cuarteles.
        destino:   Objeto de geopy con coordenadas del punto de emergencia.
        origen:    Diccionario del cuartel seleccionado por A*.

    Returns:
        folium.Map listo para renderizar.
    """
    m = folium.Map(
        location=[destino.latitude, destino.longitude],
        zoom_start=14,
        tiles="CartoDB dark_matter",
    )
    colores = ["red", "blue", "green"]

    for i, r in enumerate(rutas):
        puntos = [(lat, lon) for lon, lat in r["ruta"]]
        folium.PolyLine(
            puntos,
            color=colores[i],
            weight=7 if i == 0 else 4,
            opacity=0.85,
            tooltip=f"Ruta {i+1}",
        ).add_to(m)

    for c in cuarteles:
        if c["nombre"] == origen["nombre"]:
            folium.Marker(
                [c["lat"], c["lon"]],
                tooltip=f"🚒 Sale desde {c['nombre']}",
                popup=f"Origen: {c['nombre']}",
                icon=folium.Icon(color="green", icon="home"),
            ).add_to(m)
        else:
            folium.Marker(
                [c["lat"], c["lon"]],
                tooltip=c["nombre"],
                icon=folium.Icon(color="blue", icon="fire"),
            ).add_to(m)

    folium.Marker(
        [destino.latitude, destino.longitude],
        tooltip="🚨 Emergencia",
        popup="Destino",
        icon=folium.Icon(color="red", icon="info-sign"),
    ).add_to(m)

    puntos_total = [(lat, lon) for lon, lat in rutas[0]["ruta"]]
    m.fit_bounds(puntos_total)
    return m
