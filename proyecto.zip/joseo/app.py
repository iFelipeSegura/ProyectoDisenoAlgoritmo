# app.py
# Punto de Entrada: Orquestador principal de J.O.S.E-O

import streamlit as st
from geopy.geocoders import Nominatim

from data.cuarteles import obtener_cuarteles
from services.routing import mejor_cuartel_hibrido
from ui.components import (
    render_cuarteles_chips,
    render_header,
    render_mapa,
    render_mapa_vacio,
    render_resultado,
    render_rutas,
)
from ui.styles import CSS

# =========================================================
# CONFIGURACIÓN DE PÁGINA Y ESTILOS
# =========================================================
st.set_page_config(layout="wide", page_title="J.O.S.E-O", page_icon="🚒")
st.markdown(CSS, unsafe_allow_html=True)

# =========================================================
# DATOS
# =========================================================
cuarteles = obtener_cuarteles()

# =========================================================
# INTERFAZ
# =========================================================
render_header()

col_left, col_right = st.columns([1, 2.2], gap="large")

with col_left:
    render_cuarteles_chips(cuarteles)

    st.markdown('<p class="section-label">Dirección de emergencia</p>', unsafe_allow_html=True)
    direccion = st.text_input(
        "Dirección de emergencia",
        placeholder="Ej: Av. Francisco de Aguirre 100",
        label_visibility="collapsed",
    )
    calcular = st.button("⬤  CALCULAR RUTA")

    if calcular:
        if direccion.strip() == "":
            st.warning("Ingrese una dirección.")
        else:
            with st.spinner("ORS generando rutas · A* evaluando waypoints..."):
                try:
                    geo = Nominatim(user_agent="joseo_app")
                    destino = geo.geocode(direccion + ", La Serena, Chile")
                    if destino is None:
                        st.error("No se encontró la dirección.")
                    else:
                        resultado = mejor_cuartel_hibrido(cuarteles, destino)
                        for aviso in resultado.get("advertencias", []):
                            st.warning(aviso)
                        st.session_state["resultado"] = resultado
                        st.session_state["destino"] = destino
                        st.session_state["cuarteles"] = cuarteles
                except Exception as e:
                    st.error(f"Error: {e}")

    if "resultado" in st.session_state:
        r = st.session_state["resultado"]
        render_resultado(r)
        render_rutas(r["rutas"])

with col_right:
    if "resultado" in st.session_state:
        r = st.session_state["resultado"]
        destino = st.session_state["destino"]
        cuarteles_sess = st.session_state["cuarteles"]
        render_mapa(r, destino, cuarteles_sess)
    else:
        render_mapa_vacio()
