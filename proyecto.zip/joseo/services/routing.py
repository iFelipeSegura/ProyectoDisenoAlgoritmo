# services/routing.py
# Capa de Servicios: Lógica de enrutamiento y algoritmos A*

import logging
import math

import networkx as nx
import openrouteservice

from config import API_KEY

logger = logging.getLogger(__name__)

client = openrouteservice.Client(key=API_KEY)


# ---------------------------------------------------------
# ORS: OBTENER RUTAS REALES CON WAYPOINTS
# ---------------------------------------------------------
def obtener_rutas_api(origen, destino):
    """
    Llama a ORS y retorna hasta 3 rutas alternativas.
    Cada ruta incluye geometría completa (waypoints), distancia y tiempo.
    """
    coords = [
        (origen["lon"], origen["lat"]),
        (destino.longitude, destino.latitude),
    ]
    res = client.directions(
        coordinates=coords,
        profile="driving-car",
        format="geojson",
        alternative_routes={"target_count": 3, "weight_factor": 1.6},
    )
    rutas = []
    for feature in res["features"]:
        geometry = feature["geometry"]["coordinates"]
        summary = feature["properties"]["summary"]
        rutas.append(
            {
                "ruta": geometry,
                "dist": summary["distance"],
                "tiempo": summary["duration"],
            }
        )
    return rutas


# ---------------------------------------------------------
# HEURÍSTICA EUCLIDIANA REAL
# ---------------------------------------------------------
def heuristica_euclidiana(coord_nodo, coord_destino):
    """
    Estima tiempo restante desde un nodo hasta el destino.
    Usa distancia euclidiana sobre coordenadas geográficas,
    calibrada a 50 km/h promedio urbano (13.9 m/s).
    1 grado de latitud ≈ 111,000 m.
    """
    lon_u, lat_u = coord_nodo
    lon_d, lat_d = coord_destino
    dx = (lon_u - lon_d) * 111_000 * math.cos(math.radians(lat_u))
    dy = (lat_u - lat_d) * 111_000
    dist_m = math.sqrt(dx**2 + dy**2)
    return dist_m / 13.9  # segundos estimados


# ---------------------------------------------------------
# CONSTRUIR GRAFO DESDE WAYPOINTS ORS
# ---------------------------------------------------------
def construir_grafo_desde_ruta(ruta_coords, tiempo_total):
    """
    Convierte los waypoints de una ruta ORS en un grafo dirigido.
    - Cada waypoint es un nodo con sus coordenadas.
    - Las aristas entre nodos consecutivos tienen como peso el tiempo
      proporcional a la longitud del segmento.
    """
    G = nx.DiGraph()
    n = len(ruta_coords)

    longitud_total = 0.0
    segmentos = []
    for i in range(n - 1):
        lon1, lat1 = ruta_coords[i]
        lon2, lat2 = ruta_coords[i + 1]
        dx = (lon2 - lon1) * 111_000 * math.cos(math.radians(lat1))
        dy = (lat2 - lat1) * 111_000
        seg_dist = math.sqrt(dx**2 + dy**2)
        segmentos.append(seg_dist)
        longitud_total += seg_dist

    for i, (lon, lat) in enumerate(ruta_coords):
        G.add_node(i, coords=(lon, lat))

    for i, seg_dist in enumerate(segmentos):
        proporcion = seg_dist / longitud_total if longitud_total > 0 else 1.0 / n
        tiempo_seg = tiempo_total * proporcion
        G.add_edge(i, i + 1, weight=tiempo_seg)

    return G


# ---------------------------------------------------------
# A* REAL SOBRE GRAFO DE WAYPOINTS
# ---------------------------------------------------------
def astar_sobre_ruta(G, coord_destino):
    """
    Ejecuta A* desde nodo 0 (cuartel) hasta el último nodo (destino).

    f(n) = g(n) + h(n)
      g(n): tiempo acumulado real desde el cuartel hasta el nodo n
      h(n): tiempo estimado desde n hasta el destino (heurística euclidiana)

    La heurística es ADMISIBLE: nunca sobreestima el costo real,
    lo que garantiza que A* encuentra la solución óptima.
    """
    nodo_inicio = 0
    nodo_destino = max(G.nodes())

    def h(u, v):
        coord_u = G.nodes[u]["coords"]
        return heuristica_euclidiana(coord_u, coord_destino)

    path = nx.astar_path(G, nodo_inicio, nodo_destino, heuristic=h, weight="weight")
    costo = nx.path_weight(G, path, weight="weight")
    return path, costo


# ---------------------------------------------------------
# NÚCLEO HÍBRIDO: ORS → grafo waypoints → A* real
# ---------------------------------------------------------
def mejor_cuartel_hibrido(cuarteles, destino):
    """
    Flujo híbrido ORS + A*:

    1. ORS genera hasta 3 rutas reales con waypoints por cada cuartel.
    2. Cada ruta se convierte en un grafo dirigido de waypoints.
    3. A* con heurística euclidiana evalúa cada grafo y calcula el
       costo óptimo de travesía nodo a nodo.
    4. Se selecciona el cuartel cuya mejor ruta A* tenga menor costo.
    """
    coord_destino = (destino.longitude, destino.latitude)
    mejor_cuartel = None
    mejor_costo = float("inf")
    todos_los_datos = {}
    errores = []

    for c in cuarteles:
        try:
            rutas = obtener_rutas_api(c, destino)
            costo_min_cuartel = float("inf")
            idx_mejor_ruta = 0

            for idx, ruta in enumerate(rutas):
                G = construir_grafo_desde_ruta(ruta["ruta"], ruta["tiempo"])
                _, costo_astar = astar_sobre_ruta(G, coord_destino)

                if costo_astar < costo_min_cuartel:
                    costo_min_cuartel = costo_astar
                    idx_mejor_ruta = idx

            todos_los_datos[c["nombre"]] = {
                "cuartel": c,
                "rutas": rutas,
                "costo_astar": costo_min_cuartel,
                "idx_mejor": idx_mejor_ruta,
            }

            if costo_min_cuartel < mejor_costo:
                mejor_costo = costo_min_cuartel
                mejor_cuartel = c["nombre"]

        except Exception as e:
            msg = f"Error procesando {c['nombre']}: {e}"
            logger.warning(msg)
            errores.append(msg)

    if mejor_cuartel is None:
        raise ValueError("No se pudo calcular ninguna ruta.")

    datos = todos_los_datos[mejor_cuartel]
    rutas_ordenadas = datos["rutas"].copy()
    idx_mejor = datos["idx_mejor"]
    if idx_mejor != 0:
        rutas_ordenadas.insert(0, rutas_ordenadas.pop(idx_mejor))

    return {
        "cuartel": datos["cuartel"],
        "rutas": rutas_ordenadas,
        "costo_astar": datos["costo_astar"],
        "advertencias": errores,
    }
