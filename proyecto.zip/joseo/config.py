# config.py
# Capa de Configuración: Constantes y claves de API

API_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6ImFjZGMxNzczOThmYzUyZGRhNDFmNTZhNjNkNGJjMTA0OTRkNzdjMTIxYjhmNjE1MmQ0NDg2YjViIiwiaCI6Im11cm11cjY0In0="

LUGAR = "La Serena, Chile"
