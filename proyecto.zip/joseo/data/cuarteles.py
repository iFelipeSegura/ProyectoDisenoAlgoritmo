# data/cuarteles.py
# Capa de Datos: Persistencia y modelos de los cuarteles

import streamlit as st


@st.cache_data
def obtener_cuarteles():
    """
    Retorna la lista de cuarteles de bomberos con sus coordenadas.
    Usa caché de Streamlit para evitar recargas innecesarias.
    """
    return [
        {"nombre": "1ra Compañía", "lat": -29.9045, "lon": -71.2519},
        {"nombre": "2da Compañía", "lat": -29.9070, "lon": -71.2600},
        {"nombre": "3ra Compañía", "lat": -29.9200, "lon": -71.2500},
        {"nombre": "4ta Compañía", "lat": -29.8800, "lon": -71.2400},
    ]
