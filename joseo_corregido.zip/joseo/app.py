
import streamlit as st
from geopy.geocoders import Nominatim
from streamlit_folium import st_folium

from data.cuarteles import obtener_cuarteles
from services.routing import obtener_rutas
from ui.map_view import crear_mapa
from ui.styles import load_css

st.set_page_config(layout="wide")

load_css()

st.markdown('<div class="joseo-title">JOSEO</div>', unsafe_allow_html=True)

direccion = st.text_input("Dirección")

if st.button("Calcular"):
    geo = Nominatim(user_agent="joseo")

    destino = geo.geocode(direccion + ", La Serena, Chile")

    cuarteles = obtener_cuarteles()

    rutas = obtener_rutas(cuarteles[0], destino)

    st.success("API funcionando correctamente")

    mapa = crear_mapa(destino, cuarteles)

    st_folium(mapa, width=900, height=500)
