
import openrouteservice
from config import API_KEY

client = openrouteservice.Client(key=API_KEY)

def obtener_rutas(origen, destino):
    coords = [
        (origen["lon"], origen["lat"]),
        (destino.longitude, destino.latitude)
    ]

    return client.directions(
        coordinates=coords,
        profile="driving-car",
        format="geojson"
    )
