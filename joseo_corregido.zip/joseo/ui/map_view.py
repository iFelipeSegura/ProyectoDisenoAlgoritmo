
import folium

def crear_mapa(destino, cuarteles):
    m = folium.Map(
        location=[destino.latitude, destino.longitude],
        zoom_start=13
    )

    for c in cuarteles:
        folium.Marker(
            [c["lat"], c["lon"]],
            tooltip=c["nombre"]
        ).add_to(m)

    folium.Marker(
        [destino.latitude, destino.longitude],
        tooltip="Destino"
    ).add_to(m)

    return m
